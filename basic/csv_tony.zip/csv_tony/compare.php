<?php
$orgfile = fopen('sku.csv', 'r');
$testfile = fopen('sku_db.csv', 'r');
$difffile = fopen('diffsku.csv', 'w');
$matchfile = fopen('matchsku.csv', 'w');
$orgarray = array();
$testarray = array();
$temp_array = array();
$counter2 =0;
while (($line = fgetcsv($orgfile)) !== FALSE) {
  
    $orgarray[$counter]=$line[0];
    //fputcsv($file1,$query_array[$counter]);
    $counter++;
    //echo "<br>";
}

while (($line = fgetcsv($testfile)) !== FALSE) {
  
    $testarray[$counter]=$line[0];
    //fputcsv($file1,$query_array[$counter]);
    $counter++;
    //echo "<br>";
}
$result = array_diff($testarray,$orgarray);
foreach ($result as $value) {
	$temp_array[$counter2]=(array)$value;
    fputcsv($difffile,$temp_array[$counter2]);
    $counte2++;

}
unset($temp_array);
foreach ($testarray as $value) {
	if (in_array($value, $orgarray))
  	{
  	   $temp_array[$counter2]=(array)$value;
       fputcsv($matchfile,$temp_array[$counter2]);
       $counte2++;
  	}

}

//print_r(count($result));        
  
// echo "<pre>";
// print_r($result);
// echo array_diff($testarray,$orgarray);

?>