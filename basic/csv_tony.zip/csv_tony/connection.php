<?php
ini_set('display_errors', 1);
$servername = "localhost";
$username = "root";
$password = "ourdesignz";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
mysqli_select_db($conn,"skudb");

//echo "Connected successfully";
?>
