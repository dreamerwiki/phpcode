<?php
include_once 'connection.php';
function pdata($value)
{
    echo "<pre>";
    print_r($value);
    echo "</pre>";
}
$file = fopen('sku_db.csv', 'w');
$arr = array();
$counter =0;
$qry = "SELECT sku FROM `oc_product` WHERE `location` LIKE 'sprichards'";
$result = mysqli_query($conn,$qry) or die(mysqli_error());
// $arr = mysqli_fetch_array($result);
// print_r($arr);



while ($row = mysqli_fetch_array($result, MYSQLI_NUM )) {
    echo "<pre>";
    print_r($row[0]);
    $arr[$counter]=(array)$row[0];
    fputcsv($file,$arr[$counter]);
    $counter++;
    echo"<br>";

}
?>
