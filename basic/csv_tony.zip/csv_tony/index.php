<?php
//include_once 'connection.php';
ini_set('display_errors', 1);
function pdata($value)
{
    echo "<pre>";
    print_r($value);
    echo "</pre>";
}
$skip=0;
$query_array=array();
$file1 = fopen('sku.csv', 'w');
$file = fopen('005368000-BESTPRICE-D-CSVShort.csv', 'r');
$counter =0;
while (($line = fgetcsv($file)) !== FALSE) {
  if($skip!=0)
  {
    $sp_item = $line[14];
    $cp_cell_price = $line[9]; 
    $sp_sell_price = $line[17];
    $price = 0.0;
    if($cp_cell_price == 0.00){
        $price = $sp_sell_price;
       } 
       else{

        $price = $cp_cell_price;
       }
    //echo("update test SET price=$price WHERE sku='$sp_item';");
    //echo"</br>sp_item = ".$line[14]."<br>cp_cell_price = ".$line[9]."<br>sp_sell_price = ".$line[17]."<br>";
    //INSERT INTO test (price,sku) VALUES (0,'ghgh')
    // $statement = "update test SET price=$price WHERE sku='$sp_item';"   
    // array_push($query_array, "update test SET price=$price WHERE sku='$sp_item';"); 
    //echo $sp_item;
    $query_array[$counter]=(array)$line[0];
    fputcsv($file1,$query_array[$counter]);
    $counter++;
    //echo "<br>";

  }
  $skip++;    
}
print_r($query_array);


